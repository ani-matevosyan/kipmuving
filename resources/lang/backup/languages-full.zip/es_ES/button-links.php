<?php

return [
	'edit'               => 'Editar',
	'delete'             => 'Borrar',
	'register'           => 'Registrar',
	'login'              => 'Entrar',
	'search'             => 'Buscar',
	'activities'         => 'Actividades',
	'agencies'           => 'Agencias',
	'guide'              => 'Guia Pucon',
	'my_agenda'          => 'Mi agenda',
	'go_to_guide'        => 'Ir a la guía',
	'view'               => 'Visualizar',
	'see_all_activities' => 'Ver todas las actividades'
];
