<?php

return [
	'password' => 'As senhas devem ter pelo menos seis caracteres e corresponder à confirmação.',
	'reset'    => 'Sua senha foi redefinida!',
	'sent'     => 'Nós enviamos seu link de redefinição de senha por e-mail!',
	'token'    => 'Este token de redefinição de senha é inválido.',
	'user'     => "Não é possível encontrar um usuário com esse endereço de e-mail.",
];