<?php

return [
	'failed'   => 'Essas credenciais não correspondem aos nossos registros',
	'throttle' => 'Demasiadas tentativas de início de sessão. Tente novamente em segundos',
];