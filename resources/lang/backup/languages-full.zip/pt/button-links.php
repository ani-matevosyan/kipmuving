<?php

return [
	'edit'               => 'Editar',
	'delete'             => 'Apagar',
	'register'           => 'Registrar',
	'login'              => 'Entrada',
	'search'             => 'Buscar',
	'activities'         => 'Atividades',
	'agencies'           => 'Agencias',
	'guide'              => 'Guia Pucon',
	'my_agenda'          => 'Minha agenda',
	'go_to_guide'        => 'Ir ao guía',
	'view'               => 'Visualizar',
	'see_all_activities' => 'Ver todas las atividades'
];
