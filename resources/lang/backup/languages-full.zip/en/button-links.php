<?php

return [
	'edit'               => 'Edit',
	'delete'             => 'Delete',
	'register'           => 'Register',
	'login'              => 'Login',
	'search'             => 'Search',
	'activities'         => 'Activities',
	'agencies'           => 'Agencies',
	'guide'              => 'Pucon guide',
	'my_agenda'          => 'My agenda',
	'go_to_guide'        => 'Go to guide',
	'view'               => 'View',
	'see_all_activities' => 'See all activities'
];
